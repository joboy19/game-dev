run python game.py to start the game.
make sure pygame is installed and python version is 3.7+ (it does not work on python 3.5, but tested on
uni windows systems)
i used audio which i did not create, and were found in an external resource.